# EventHub API

Tadbirlar (konsert, IT-meetup, stand-up, master-klass) va chiptalarni bron qilish tizimining backend qismi.
**Node.js + Express**, ma'lumotlar JSON fayllarda saqlanadi, validatsiya — **Joi**, parollar — **bcrypt**, email — **Nodemailer**.

Frontend yo'q — hamma narsa **Postman** orqali tekshiriladi. Server **3000-portda** ishlaydi.

## O'rnatish

```bash
npm install
```

`.env` fayl tayyor (`.env.example` dan nusxa). Email sozlamalari:

- **MAIL_USER / MAIL_PASS bo'sh** (standart) — avtomatik **Ethereal** test pochta ishlatiladi. Haqiqiy email ketmaydi;
  yuborilgan xatni ko'rish havolasi **terminalda** chiqadi (tasdiqlash kodini shu yerdan olasiz).
  Internet bo'lmasa — xat matni terminalning o'zida chiqadi.
- **Gmail** uchun: `MAIL_USER` — gmail manzilingiz, `MAIL_PASS` — **App Password** (oddiy parol emas).

## Ishga tushirish

```bash
npm run dev      # nodemon bilan (avto-restart)
# yoki
npm start
```

Tekshirish: `GET http://localhost:3000/api/health` → `{ "status": "ok" }`

## Postman

`postman_collection.json` ni Postman'ga **Import** qiling. `baseUrl` = `http://localhost:3000`.
Har bir endpoint uchun namunaviy body bor.

**Tavsiya etilgan tekshiruv tartibi:**
1. Register → terminaldan 6 xonali kodni oling
2. Verify email (kodni yuboring) → Login
3. `GET /api/events` → `POST /api/bookings` → terminalda chipta emailini ko'ring
4. Bronni o'zgartirish / bekor qilish

## Endpointlar (24 ta)

| Method | URL | Tavsif |
|---|---|---|
| GET | /api/health | Server holati |
| POST | /api/auth/register | Ro'yxatdan o'tish (+ email kodi) |
| POST | /api/auth/verify-email | Emailni tasdiqlash |
| POST | /api/auth/resend-code | Kodni qayta yuborish (60 soniya) |
| POST | /api/auth/login | Kirish |
| POST | /api/auth/forgot-password | Parolni tiklash kodi |
| POST | /api/auth/reset-password | Kod bilan yangi parol |
| GET | /api/users/:id | Profil + activeBookings |
| PUT | /api/users/:id | Ismni o'zgartirish |
| PUT | /api/users/:id/password | Parolni o'zgartirish |
| DELETE | /api/users/:id | Akkauntni o'chirish (parol bilan) |
| GET | /api/users/:id/bookings | Foydalanuvchi bronlari |
| POST | /api/events | Tadbir yaratish |
| GET | /api/events | Ro'yxat: search, category, city, free, sort, page, limit, all |
| GET | /api/events/:id | Tadbir + bookedSeats |
| PUT | /api/events/:id | Tadbirni yangilash |
| DELETE | /api/events/:id | O'chirish + ishtirokchilarga email |
| GET | /api/events/:id/bookings | Tadbirga yozilganlar + jami |
| POST | /api/bookings | Bron qilish (1–5 joy) + email chipta |
| GET | /api/bookings | Bronlar: status, event_id, page, limit |
| GET | /api/bookings/:id | Bron tafsilotlari |
| PUT | /api/bookings/:id | Joylar sonini o'zgartirish |
| PUT | /api/bookings/:id/cancel | Bekor qilish (24 soat qoidasi) |
| DELETE | /api/bookings/:id | Bronni o'chirish |

## Javob formati

```json
{ "success": true, "message": "...", "data": { } }
{ "success": true, "data": [ ], "meta": { "page": 1, "limit": 10, "total": 47, "totalPages": 5 } }
{ "success": false, "message": "Validatsiya xatosi", "errors": [ { "field": "email", "message": "..." } ] }
```

## Struktura

```
data/         JSON "baza" (users, codes, events, bookings)
src/routes/        faqat URL -> controller
src/controllers/   barcha logika
src/validations/   Joi sxemalar
src/utils/         fileDb, mailer, generateCode, emailTemplates, helpers, validate
```
