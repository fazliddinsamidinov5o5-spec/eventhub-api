// src/utils/mailer.js — nodemailer transporter + sendMail
const nodemailer = require("nodemailer");

let transporterPromise = null;

async function createTransporter() {
  const { MAIL_HOST, MAIL_PORT, MAIL_USER, MAIL_PASS } = process.env;

  // 1) .env da MAIL_USER/MAIL_PASS bo'lsa — haqiqiy SMTP (Gmail App Password, Mailtrap va h.k.)
  if (MAIL_USER && MAIL_PASS) {
    const port = Number(MAIL_PORT) || 587;
    return {
      mode: "smtp",
      transporter: nodemailer.createTransport({
        host: MAIL_HOST || "smtp.gmail.com",
        port,
        secure: port === 465,
        auth: { user: MAIL_USER, pass: MAIL_PASS },
      }),
    };
  }

  // 2) Aks holda — Ethereal (test pochta, haqiqiy email ketmaydi)
  try {
    const account = await nodemailer.createTestAccount();
    console.log("ℹ  MAIL_USER/MAIL_PASS berilmagan — Ethereal test pochta ishlatilmoqda.");
    return {
      mode: "ethereal",
      transporter: nodemailer.createTransport({
        host: "smtp.ethereal.email",
        port: 587,
        secure: false,
        auth: { user: account.user, pass: account.pass },
      }),
    };
  } catch (err) {
    // 3) Internet yo'q bo'lsa — emailni faqat konsolga chiqaradi
    console.warn("⚠  Ethereal ulanmadi, email konsolga chiqariladi:", err.message);
    return { mode: "console", transporter: nodemailer.createTransport({ jsonTransport: true }) };
  }
}

const getTransporter = () => {
  if (!transporterPromise) transporterPromise = createTransporter();
  return transporterPromise;
};

// Xato bo'lsa reject qiladi (Promise.allSettled bilan ishlatish uchun)
async function sendMail({ to, subject, html, text }) {
  const { transporter, mode } = await getTransporter();
  const info = await transporter.sendMail({
    from: process.env.MAIL_FROM || "EventHub <no-reply@eventhub.uz>",
    to,
    subject,
    html,
    text,
  });

  if (mode === "ethereal") {
    console.log(`✉  Email yuborildi (${to}). Ko'rish: ${nodemailer.getTestMessageUrl(info)}`);
  } else if (mode === "console") {
    console.log(`✉  [simulyatsiya] ${to} | ${subject}\n${text}`);
  } else {
    console.log(`✉  Email yuborildi: ${to} | ${subject}`);
  }
  return info;
}

// Xato bo'lsa so'rovni yiqitmaydi — faqat console.error qiladi
async function safeSendMail(to, template) {
  try {
    await sendMail({ to, ...template });
    return true;
  } catch (err) {
    console.error(`Email yuborishda xato (${to}):`, err.message);
    return false;
  }
}

module.exports = { sendMail, safeSendMail };
