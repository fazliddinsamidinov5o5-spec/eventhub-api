// src/utils/helpers.js — umumiy yordamchi funksiyalar

class ApiError extends Error {
  constructor(status, message, errors) {
    super(message);
    this.status = status;
    this.errors = errors;
  }
}

// async controllerlardagi xatolarni Express'ning xato handleriga uzatadi
const wrap = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

// id = massivdagi eng katta id + 1 (bo'sh bo'lsa — 1)
const nextId = (arr) => (arr.length ? Math.max(...arr.map((i) => i.id)) + 1 : 1);

// password maydonini olib tashlaydi
const publicUser = (user) => {
  const { password, ...safe } = user;
  return safe;
};

const success = (res, status, message, data) =>
  res.status(status).json({ success: true, message, data });

// { page, limit } bo'yicha massivni qirqadi va meta qaytaradi
const paginate = (items, page, limit) => {
  const total = items.length;
  return {
    data: items.slice((page - 1) * limit, page * limit),
    meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
  };
};

module.exports = { ApiError, wrap, nextId, publicUser, success, paginate };
