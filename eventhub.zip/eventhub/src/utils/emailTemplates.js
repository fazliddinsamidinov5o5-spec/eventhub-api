// src/utils/emailTemplates.js — HTML email shablonlar
const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const fmtDate = (iso) =>
  new Date(iso).toLocaleString("ru-RU", {
    timeZone: "Asia/Tashkent",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }) + " (Toshkent vaqti)";

const fmtPrice = (n) => (Number(n) === 0 ? "Bepul" : `${Number(n).toLocaleString("ru-RU")} so'm`);

const layout = (title, inner) => `<!DOCTYPE html>
<html lang="uz"><body style="margin:0;padding:24px;background:#f3f4f8;font-family:Arial,Helvetica,sans-serif;">
  <div style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
    <div style="background:#4f46e5;color:#ffffff;padding:20px 28px;font-size:22px;font-weight:bold;">🎟 EventHub</div>
    <div style="padding:28px;color:#1f2937;font-size:15px;line-height:1.6;">
      <h2 style="margin-top:0;color:#111827;">${title}</h2>
      ${inner}
    </div>
    <div style="padding:16px 28px;background:#f9fafb;color:#6b7280;font-size:12px;">Bu avtomatik xabar. Iltimos, unga javob bermang.</div>
  </div>
</body></html>`;

const codeBox = (code) =>
  `<div style="text-align:center;margin:24px 0;"><span style="display:inline-block;background:#eef2ff;color:#4338ca;font-size:34px;font-weight:bold;letter-spacing:8px;padding:14px 28px;border-radius:10px;">${esc(code)}</span></div>`;

const row = (label, value) =>
  `<tr><td style="padding:8px 12px;border:1px solid #e5e7eb;background:#f9fafb;width:40%;"><b>${label}</b></td><td style="padding:8px 12px;border:1px solid #e5e7eb;">${value}</td></tr>`;

const table = (rows) =>
  `<table style="width:100%;border-collapse:collapse;margin:16px 0;">${rows.join("")}</table>`;

exports.verificationEmail = (name, code) => ({
  subject: "EventHub: emailingizni tasdiqlang",
  html: layout(
    `Salom, ${esc(name)}!`,
    `<p>EventHub'ga xush kelibsiz. Ro'yxatdan o'tishni yakunlash uchun quyidagi tasdiqlash kodini kiriting:</p>
     ${codeBox(code)}
     <p style="color:#b45309;"><b>Kod 10 daqiqa amal qiladi.</b></p>
     <p>Agar siz ro'yxatdan o'tmagan bo'lsangiz, bu xabarni e'tiborsiz qoldiring.</p>`
  ),
  text: `Salom, ${name}! Tasdiqlash kodingiz: ${code} (10 daqiqa amal qiladi).`,
});

exports.welcomeEmail = (name) => ({
  subject: "EventHub'ga xush kelibsiz!",
  html: layout(
    `Xush kelibsiz, ${esc(name)}! 🎉`,
    `<p>Emailingiz muvaffaqiyatli tasdiqlandi. Endi tadbirlarni ko'rib, joy bron qilishingiz mumkin.</p>`
  ),
  text: `Xush kelibsiz, ${name}! Emailingiz tasdiqlandi.`,
});

exports.resetPasswordEmail = (name, code) => ({
  subject: "EventHub: parolni tiklash kodi",
  html: layout(
    `Parolni tiklash`,
    `<p>Salom, ${esc(name)}. Parolingizni tiklash uchun quyidagi koddan foydalaning:</p>
     ${codeBox(code)}
     <p style="color:#b45309;"><b>Kod 10 daqiqa amal qiladi.</b></p>
     <p>Agar bu so'rovni siz yubormagan bo'lsangiz, xabarni e'tiborsiz qoldiring.</p>`
  ),
  text: `Parolni tiklash kodi: ${code} (10 daqiqa amal qiladi).`,
});

exports.passwordChangedEmail = (name) => ({
  subject: "EventHub: parolingiz o'zgartirildi",
  html: layout(
    `Parol o'zgartirildi`,
    `<p>Salom, ${esc(name)}. Parolingiz o'zgartirildi.</p>
     <p style="color:#b91c1c;"><b>Agar bu siz bo'lmasangiz, darhol parolni tiklang yoki qo'llab-quvvatlash xizmatiga murojaat qiling.</b></p>`
  ),
  text: `Parolingiz o'zgartirildi. Agar bu siz bo'lmasangiz, darhol parolni tiklang.`,
});

const bookingTable = (event, booking) =>
  table([
    row("Tadbir", esc(event.title)),
    row("Sana va vaqt", fmtDate(event.starts_at)),
    row("Manzil", `${esc(event.venue)}, ${esc(event.city)}`),
    row("Joylar soni", booking.seats),
    row("Umumiy narx", fmtPrice(booking.total_price)),
    row("Chipta kodi", `<b style="font-size:18px;letter-spacing:2px;color:#4338ca;">${esc(booking.ticket_code)}</b>`),
  ]);

exports.bookingTicketEmail = (name, event, booking) => ({
  subject: `Chiptangiz: ${event.title} (${booking.ticket_code})`,
  html: layout(
    `Broningiz tasdiqlandi ✅`,
    `<p>Salom, ${esc(name)}! Joy muvaffaqiyatli bron qilindi. Chipta ma'lumotlari:</p>
     ${bookingTable(event, booking)}
     <p>Tadbirda shu chipta kodini ko'rsating.</p>`
  ),
  text: `Bron tasdiqlandi. Tadbir: ${event.title}. Joylar: ${booking.seats}. Chipta kodi: ${booking.ticket_code}`,
});

exports.bookingUpdatedEmail = (name, event, booking) => ({
  subject: `Broningiz o'zgartirildi (${booking.ticket_code})`,
  html: layout(
    `Broningiz o'zgartirildi`,
    `<p>Salom, ${esc(name)}! Broningiz yangilandi:</p>${bookingTable(event, booking)}`
  ),
  text: `Broningiz o'zgartirildi. Tadbir: ${event.title}. Yangi joylar soni: ${booking.seats}. Kod: ${booking.ticket_code}`,
});

exports.bookingCancelledEmail = (name, event, booking) => ({
  subject: `Broningiz bekor qilindi (${booking.ticket_code})`,
  html: layout(
    `Broningiz bekor qilindi`,
    `<p>Salom, ${esc(name)}! Quyidagi broningiz bekor qilindi:</p>${bookingTable(event, booking)}
     <p>Joylar tadbirga qaytarildi.</p>`
  ),
  text: `Broningiz bekor qilindi. Tadbir: ${event.title}. Kod: ${booking.ticket_code}`,
});

exports.eventCancelledEmail = (name, event) => ({
  subject: `Tadbir bekor qilindi: ${event.title}`,
  html: layout(
    `Tadbir bekor qilindi`,
    `<p>Salom, ${esc(name)}. Afsuski, quyidagi tadbir bekor qilindi va broningiz ham bekor qilindi:</p>
     ${table([
       row("Tadbir", esc(event.title)),
       row("Sana va vaqt", fmtDate(event.starts_at)),
       row("Manzil", `${esc(event.venue)}, ${esc(event.city)}`),
     ])}
     <p>Noqulaylik uchun uzr so'raymiz.</p>`
  ),
  text: `Tadbir bekor qilindi: ${event.title}. Broningiz ham bekor qilindi.`,
});
