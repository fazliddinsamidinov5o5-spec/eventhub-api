// src/utils/generateCode.js — OTP va chipta kodi
const crypto = require("crypto");

// 6 xonali tasodifiy kod (string)
const generateOtp = () => String(crypto.randomInt(100000, 1000000));

const CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

// EVH-7K2Q9X ko'rinishidagi kod; mavjud kodlar bilan takrorlanmaydi
function generateTicketCode(existingCodes = []) {
  const taken = new Set(existingCodes);
  let code;
  do {
    let part = "";
    for (let i = 0; i < 6; i++) part += CHARS[crypto.randomInt(0, CHARS.length)];
    code = `EVH-${part}`;
  } while (taken.has(code));
  return code;
}

module.exports = { generateOtp, generateTicketCode };
