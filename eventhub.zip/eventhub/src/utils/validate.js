// src/utils/validate.js — Joi bilan tekshirish (xato bo'lsa ApiError tashlaydi)
const { ApiError } = require("./helpers");

const messages = {
  "any.required": "{#label} majburiy",
  "any.only": "{#label} faqat quyidagilardan biri bo'lishi kerak: {#valids}",
  "string.base": "{#label} matn bo'lishi kerak",
  "string.empty": "{#label} bo'sh bo'lmasligi kerak",
  "string.min": "{#label} kamida {#limit} belgidan iborat bo'lishi kerak",
  "string.max": "{#label} {#limit} belgidan oshmasligi kerak",
  "string.email": "{#label} noto'g'ri formatda",
  "string.pattern.base": "{#label} noto'g'ri formatda",
  "number.base": "{#label} son bo'lishi kerak",
  "number.integer": "{#label} butun son bo'lishi kerak",
  "number.positive": "{#label} musbat son bo'lishi kerak",
  "number.min": "{#label} kamida {#limit} bo'lishi kerak",
  "number.max": "{#label} {#limit} dan oshmasligi kerak",
  "boolean.base": "{#label} true yoki false bo'lishi kerak",
  "date.base": "{#label} to'g'ri sana bo'lishi kerak",
  "date.format": "{#label} ISO formatda bo'lishi kerak (masalan 2026-11-15T18:00:00)",
  "date.greater": "{#label} kelajakdagi sana bo'lishi kerak",
  "object.base": "So'rov tanasi obyekt bo'lishi kerak",
  "object.min": "Kamida bitta maydon yuborilishi kerak",
};

function validate(schema, data) {
  const { error, value } = schema.validate(data ?? {}, {
    abortEarly: false,
    stripUnknown: true,
    messages,
    errors: { wrap: { label: false } },
  });
  if (error) {
    throw new ApiError(
      400,
      "Validatsiya xatosi",
      error.details.map((d) => ({
        field: d.path.join(".") || "body",
        message: d.message,
      }))
    );
  }
  return value;
}

module.exports = { validate };
