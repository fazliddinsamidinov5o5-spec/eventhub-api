// src/routes/booking.routes.js
const router = require("express").Router();
const c = require("../controllers/booking.controller");

router.post("/", c.createBooking);
router.get("/", c.getBookings);
router.get("/:id", c.getBookingById);
router.put("/:id", c.updateBooking);
router.put("/:id/cancel", c.cancelBooking);
router.delete("/:id", c.deleteBooking);

module.exports = router;
