// src/validations/common.validation.js
const Joi = require("joi");

const id = Joi.number().integer().positive().required();

const idParam = Joi.object({ id });

module.exports = { id, idParam };
