// src/validations/booking.validation.js
const Joi = require("joi");

const positiveInt = Joi.number().integer().positive();
const seats = Joi.number().integer().min(1).max(5);

exports.createBookingSchema = Joi.object({
  user_id: positiveInt.required(),
  event_id: positiveInt.required(),
  seats: seats.required(),
});

exports.updateBookingSchema = Joi.object({ seats: seats.required() });

exports.listBookingsQuery = Joi.object({
  status: Joi.string().valid("confirmed", "cancelled"),
  event_id: positiveInt,
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(50).default(10),
});
