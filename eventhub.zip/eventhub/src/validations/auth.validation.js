// src/validations/auth.validation.js
const Joi = require("joi");

const email = Joi.string()
  .trim()
  .lowercase()
  .email({ tlds: { allow: false } })
  .required();

const strongPassword = Joi.string()
  .min(8)
  .max(64)
  .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/)
  .required()
  .messages({
    "string.pattern.base":
      "{#label} kamida 1 ta katta harf, 1 ta kichik harf va 1 ta raqamdan iborat bo'lishi kerak",
  });

const code = Joi.string()
  .pattern(/^\d{6}$/)
  .required()
  .messages({ "string.pattern.base": "code 6 xonali raqam bo'lishi kerak" });

const fullName = Joi.string().trim().min(3).max(100).required();

exports.registerSchema = Joi.object({ full_name: fullName, email, password: strongPassword });
exports.verifyEmailSchema = Joi.object({ email, code });
exports.resendCodeSchema = Joi.object({ email });
exports.loginSchema = Joi.object({ email, password: Joi.string().required() });
exports.forgotPasswordSchema = Joi.object({ email });
exports.resetPasswordSchema = Joi.object({ email, code, new_password: strongPassword });

exports.updateProfileSchema = Joi.object({ full_name: fullName });
exports.changePasswordSchema = Joi.object({
  old_password: Joi.string().required(),
  new_password: strongPassword,
});
exports.deleteAccountSchema = Joi.object({ password: Joi.string().required() });
