// src/app.js
const express = require("express");

const authRoutes = require("./routes/auth.routes");
const userRoutes = require("./routes/user.routes");
const eventRoutes = require("./routes/event.routes");
const bookingRoutes = require("./routes/booking.routes");

const app = express();

app.use(express.json());

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/events", eventRoutes);
app.use("/api/bookings", bookingRoutes);

// Mavjud bo'lmagan route
app.use((req, res) => {
  res.status(404).json({ success: false, message: "Route topilmadi" });
});

// Markaziy xato handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  // Noto'g'ri JSON yuborilgan bo'lsa
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ success: false, message: "JSON formati noto'g'ri" });
  }
  // Bizning xatolarimiz (validatsiya, 404, 409 ...)
  if (err.status && err.status < 500) {
    const body = { success: false, message: err.message };
    if (err.errors) body.errors = err.errors;
    return res.status(err.status).json(body);
  }
  // Kutilmagan xato — stack trace ko'rsatilmaydi
  console.error(err);
  res.status(500).json({ success: false, message: "Serverda kutilmagan xatolik yuz berdi" });
});

module.exports = app;
