// src/controllers/event.controller.js
const { readData, writeData } = require("../utils/fileDb");
const { sendMail } = require("../utils/mailer");
const T = require("../utils/emailTemplates");
const { ApiError, wrap, nextId, success, paginate } = require("../utils/helpers");
const { validate } = require("../utils/validate");
const { idParam } = require("../validations/common.validation");
const V = require("../validations/event.validation");

// POST /api/events
exports.createEvent = wrap(async (req, res) => {
  const value = validate(V.createEventSchema, req.body);
  const events = await readData("events");

  const event = {
    id: nextId(events),
    title: value.title,
    description: value.description || "",
    category: value.category,
    city: value.city,
    venue: value.venue,
    starts_at: value.starts_at.toISOString(),
    price: value.price,
    capacity: value.capacity,
    available_seats: value.capacity,
    created_at: new Date().toISOString(),
  };
  events.push(event);
  await writeData("events", events);

  success(res, 201, "Tadbir yaratildi", event);
});

// GET /api/events
exports.getEvents = wrap(async (req, res) => {
  const q = validate(V.listEventsQuery, req.query);
  let events = await readData("events");

  // 1) FILTR
  if (!q.all) {
    const now = Date.now();
    events = events.filter((e) => new Date(e.starts_at).getTime() > now);
  }
  if (q.search) {
    const s = q.search.toLowerCase();
    events = events.filter(
      (e) => e.title.toLowerCase().includes(s) || (e.description || "").toLowerCase().includes(s)
    );
  }
  if (q.category) events = events.filter((e) => e.category === q.category);
  if (q.city) events = events.filter((e) => e.city.toLowerCase() === q.city.toLowerCase());
  if (q.free === true) events = events.filter((e) => e.price === 0);

  // 2) SARALASH
  const sorters = {
    date_asc: (a, b) => new Date(a.starts_at) - new Date(b.starts_at),
    date_desc: (a, b) => new Date(b.starts_at) - new Date(a.starts_at),
    price_asc: (a, b) => a.price - b.price,
    price_desc: (a, b) => b.price - a.price,
  };
  events.sort(sorters[q.sort]);

  // 3) PAGINATION (slice)
  const { data, meta } = paginate(events, q.page, q.limit);
  res.status(200).json({ success: true, data, meta });
});

// GET /api/events/:id
exports.getEventById = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);
  const events = await readData("events");
  const event = events.find((e) => e.id === id);
  if (!event) throw new ApiError(404, "Tadbir topilmadi");

  success(res, 200, "Tadbir ma'lumotlari", {
    ...event,
    bookedSeats: event.capacity - event.available_seats,
  });
});

// PUT /api/events/:id
exports.updateEvent = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);
  const value = validate(V.updateEventSchema, req.body);

  const events = await readData("events");
  const index = events.findIndex((e) => e.id === id);
  if (index === -1) throw new ApiError(404, "Tadbir topilmadi");

  const old = events[index];
  const update = { ...value };
  if (update.starts_at) update.starts_at = update.starts_at.toISOString();

  // capacity o'zgarsa: available_seats = yangi capacity - band joylar
  const booked = old.capacity - old.available_seats;
  let available = old.available_seats;
  if (update.capacity !== undefined) {
    if (update.capacity < booked) {
      throw new ApiError(400, `Allaqachon ${booked} ta joy band qilingan`);
    }
    available = update.capacity - booked;
  }

  events[index] = { ...old, ...update, available_seats: available };
  await writeData("events", events);
  success(res, 200, "Tadbir yangilandi", events[index]);
});

// DELETE /api/events/:id
exports.deleteEvent = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);

  const events = await readData("events");
  const event = events.find((e) => e.id === id);
  if (!event) throw new ApiError(404, "Tadbir topilmadi");

  await writeData("events", events.filter((e) => e.id !== id));

  // Barcha confirmed bronlarni cancelled qilamiz
  const bookings = await readData("bookings");
  const affected = bookings.filter((b) => b.event_id === id && b.status === "confirmed");
  affected.forEach((b) => (b.status = "cancelled"));
  await writeData("bookings", bookings);

  // Ishtirokchilarga email (bittasi xato bersa, qolganlari to'xtamaydi)
  const users = await readData("users");
  const recipients = [...new Set(affected.map((b) => b.user_id))]
    .map((uid) => users.find((u) => u.id === uid))
    .filter(Boolean);

  const results = await Promise.allSettled(
    recipients.map((u) => sendMail({ to: u.email, ...T.eventCancelledEmail(u.full_name, event) }))
  );
  results.forEach((r, i) => {
    if (r.status === "rejected") {
      console.error(`Email yuborishda xato (${recipients[i].email}):`, r.reason && r.reason.message);
    }
  });
  const notifiedUsers = results.filter((r) => r.status === "fulfilled").length;

  success(res, 200, "Tadbir o'chirildi", { notifiedUsers });
});

// GET /api/events/:id/bookings
exports.getEventBookings = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);

  const events = await readData("events");
  const event = events.find((e) => e.id === id);
  if (!event) throw new ApiError(404, "Tadbir topilmadi");

  const users = await readData("users");
  const bookings = (await readData("bookings")).filter(
    (b) => b.event_id === id && b.status === "confirmed"
  );

  const data = bookings.map((b) => {
    const user = users.find((u) => u.id === b.user_id);
    return {
      booking_id: b.id,
      full_name: user ? user.full_name : null,
      email: user ? user.email : null,
      seats: b.seats,
      ticket_code: b.ticket_code,
      created_at: b.created_at,
    };
  });

  const summary = {
    totalBookings: bookings.length,
    totalSeats: bookings.reduce((sum, b) => sum + b.seats, 0),
    estimatedRevenue: bookings.reduce((sum, b) => sum + b.total_price, 0),
  };

  res.status(200).json({ success: true, event: { id: event.id, title: event.title }, data, summary });
});
