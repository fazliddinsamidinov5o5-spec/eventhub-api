// src/controllers/booking.controller.js
const { readData, writeData } = require("../utils/fileDb");
const { generateTicketCode } = require("../utils/generateCode");
const { safeSendMail } = require("../utils/mailer");
const T = require("../utils/emailTemplates");
const { ApiError, wrap, nextId, success, paginate } = require("../utils/helpers");
const { validate } = require("../utils/validate");
const { idParam } = require("../validations/common.validation");
const V = require("../validations/booking.validation");

const DAY_MS = 24 * 60 * 60 * 1000;

// POST /api/bookings
exports.createBooking = wrap(async (req, res) => {
  const { user_id, event_id, seats } = validate(V.createBookingSchema, req.body);

  const users = await readData("users");
  const user = users.find((u) => u.id === user_id);
  if (!user) throw new ApiError(404, "Foydalanuvchi topilmadi");
  if (!user.is_verified) throw new ApiError(403, "Avval emailingizni tasdiqlang");

  const events = await readData("events");
  const event = events.find((e) => e.id === event_id);
  if (!event) throw new ApiError(404, "Tadbir topilmadi");
  if (new Date(event.starts_at).getTime() <= Date.now()) {
    throw new ApiError(400, "Tadbir allaqachon boshlangan");
  }

  const bookings = await readData("bookings");
  if (bookings.some((b) => b.user_id === user_id && b.event_id === event_id && b.status === "confirmed")) {
    throw new ApiError(409, "Siz bu tadbirga allaqachon yozilgansiz");
  }
  if (seats > event.available_seats) {
    throw new ApiError(400, `Faqat ${event.available_seats} ta joy qoldi`);
  }

  event.available_seats -= seats;
  await writeData("events", events);

  const booking = {
    id: nextId(bookings),
    user_id,
    event_id,
    seats,
    total_price: seats * event.price,
    ticket_code: generateTicketCode(bookings.map((b) => b.ticket_code)),
    status: "confirmed",
    created_at: new Date().toISOString(),
  };
  bookings.push(booking);
  await writeData("bookings", bookings);

  // Fayllar saqlangandan keyin email chipta
  await safeSendMail(user.email, T.bookingTicketEmail(user.full_name, event, booking));

  success(res, 201, "Joy muvaffaqiyatli bron qilindi. Chipta emailingizga yuborildi", booking);
});

// GET /api/bookings
exports.getBookings = wrap(async (req, res) => {
  const q = validate(V.listBookingsQuery, req.query);
  let bookings = await readData("bookings");

  if (q.status) bookings = bookings.filter((b) => b.status === q.status);
  if (q.event_id) bookings = bookings.filter((b) => b.event_id === q.event_id);

  const { data, meta } = paginate(bookings, q.page, q.limit);
  res.status(200).json({ success: true, data, meta });
});

// GET /api/users/:id/bookings
exports.getUserBookings = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);

  const users = await readData("users");
  if (!users.some((u) => u.id === id)) throw new ApiError(404, "Foydalanuvchi topilmadi");

  const events = await readData("events");
  const bookings = (await readData("bookings")).filter((b) => b.user_id === id);

  const data = bookings.map((b) => {
    const e = events.find((ev) => ev.id === b.event_id);
    return {
      ...b,
      event: e ? { title: e.title, starts_at: e.starts_at, venue: e.venue } : null,
    };
  });
  success(res, 200, "Foydalanuvchi bronlari", data);
});

// GET /api/bookings/:id
exports.getBookingById = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);

  const bookings = await readData("bookings");
  const booking = bookings.find((b) => b.id === id);
  if (!booking) throw new ApiError(404, "Bron topilmadi");

  const users = await readData("users");
  const events = await readData("events");
  const user = users.find((u) => u.id === booking.user_id);
  const event = events.find((e) => e.id === booking.event_id);

  success(res, 200, "Bron ma'lumotlari", {
    ...booking,
    user: user ? { id: user.id, full_name: user.full_name, email: user.email } : null,
    event: event
      ? {
          id: event.id,
          title: event.title,
          category: event.category,
          city: event.city,
          venue: event.venue,
          starts_at: event.starts_at,
          price: event.price,
        }
      : null,
  });
});

// PUT /api/bookings/:id  — faqat seats o'zgaradi
exports.updateBooking = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);
  const { seats } = validate(V.updateBookingSchema, req.body);

  const bookings = await readData("bookings");
  const booking = bookings.find((b) => b.id === id);
  if (!booking) throw new ApiError(404, "Bron topilmadi");
  if (booking.status === "cancelled") {
    throw new ApiError(400, "Bekor qilingan bronni o'zgartirib bo'lmaydi");
  }

  const events = await readData("events");
  const event = events.find((e) => e.id === booking.event_id);
  if (!event) throw new ApiError(404, "Tadbir topilmadi");

  const diff = seats - booking.seats; // > 0: ko'paytirish, < 0: kamaytirish
  if (diff > event.available_seats) {
    throw new ApiError(400, `Faqat ${event.available_seats} ta qo'shimcha joy qoldi`);
  }

  event.available_seats -= diff;
  booking.seats = seats;
  booking.total_price = seats * event.price;
  await writeData("events", events);
  await writeData("bookings", bookings);

  const users = await readData("users");
  const user = users.find((u) => u.id === booking.user_id);
  if (user) await safeSendMail(user.email, T.bookingUpdatedEmail(user.full_name, event, booking));

  success(res, 200, "Bron yangilandi", booking);
});

// PUT /api/bookings/:id/cancel
exports.cancelBooking = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);

  const bookings = await readData("bookings");
  const booking = bookings.find((b) => b.id === id);
  if (!booking) throw new ApiError(404, "Bron topilmadi");
  if (booking.status === "cancelled") throw new ApiError(400, "Bron allaqachon bekor qilingan");

  const events = await readData("events");
  const event = events.find((e) => e.id === booking.event_id);
  if (event && new Date(event.starts_at).getTime() - Date.now() < DAY_MS) {
    throw new ApiError(400, "Tadbirga 24 soatdan kam qolgani uchun bekor qilib bo'lmaydi");
  }

  booking.status = "cancelled";
  if (event) event.available_seats += booking.seats;
  await writeData("events", events);
  await writeData("bookings", bookings);

  const users = await readData("users");
  const user = users.find((u) => u.id === booking.user_id);
  if (user && event) {
    await safeSendMail(user.email, T.bookingCancelledEmail(user.full_name, event, booking));
  }

  success(res, 200, "Bron bekor qilindi", booking);
});

// DELETE /api/bookings/:id
exports.deleteBooking = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);

  const bookings = await readData("bookings");
  const booking = bookings.find((b) => b.id === id);
  if (!booking) throw new ApiError(404, "Bron topilmadi");

  // confirmed bo'lsa — avval joylarni qaytaramiz
  if (booking.status === "confirmed") {
    const events = await readData("events");
    const event = events.find((e) => e.id === booking.event_id);
    if (event) {
      event.available_seats += booking.seats;
      await writeData("events", events);
    }
  }

  await writeData("bookings", bookings.filter((b) => b.id !== id));
  success(res, 200, "Bron o'chirildi", null);
});
