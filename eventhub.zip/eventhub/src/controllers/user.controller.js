// src/controllers/user.controller.js
const bcrypt = require("bcrypt");
const { readData, writeData } = require("../utils/fileDb");
const { safeSendMail } = require("../utils/mailer");
const T = require("../utils/emailTemplates");
const { ApiError, wrap, publicUser, success } = require("../utils/helpers");
const { validate } = require("../utils/validate");
const { idParam } = require("../validations/common.validation");
const V = require("../validations/auth.validation");

async function findUser(users, id) {
  const user = users.find((u) => u.id === id);
  if (!user) throw new ApiError(404, "Foydalanuvchi topilmadi");
  return user;
}

// GET /api/users/:id
exports.getUser = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);
  const users = await readData("users");
  const user = await findUser(users, id);

  const bookings = await readData("bookings");
  const activeBookings = bookings.filter((b) => b.user_id === id && b.status === "confirmed").length;

  success(res, 200, "Foydalanuvchi ma'lumotlari", { ...publicUser(user), activeBookings });
});

// PUT /api/users/:id
exports.updateUser = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);
  const { full_name } = validate(V.updateProfileSchema, req.body);

  const users = await readData("users");
  const user = await findUser(users, id);

  user.full_name = full_name;
  await writeData("users", users);
  success(res, 200, "Profil yangilandi", publicUser(user));
});

// PUT /api/users/:id/password
exports.changePassword = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);
  const { old_password, new_password } = validate(V.changePasswordSchema, req.body);

  const users = await readData("users");
  const user = await findUser(users, id);

  if (!(await bcrypt.compare(old_password, user.password))) {
    throw new ApiError(400, "Eski parol noto'g'ri");
  }
  if (old_password === new_password) {
    throw new ApiError(400, "Yangi parol eskisi bilan bir xil bo'lmasligi kerak");
  }

  user.password = await bcrypt.hash(new_password, 10);
  await writeData("users", users);

  await safeSendMail(user.email, T.passwordChangedEmail(user.full_name));
  success(res, 200, "Parol muvaffaqiyatli o'zgartirildi", null);
});

// DELETE /api/users/:id
exports.deleteUser = wrap(async (req, res) => {
  const { id } = validate(idParam, req.params);
  const { password } = validate(V.deleteAccountSchema, req.body);

  const users = await readData("users");
  const user = await findUser(users, id);

  if (!(await bcrypt.compare(password, user.password))) {
    throw new ApiError(400, "Parol noto'g'ri");
  }

  // Faol bronlarni bekor qilib, joylarni tadbirlarga qaytaramiz
  const bookings = await readData("bookings");
  const events = await readData("events");
  let cancelled = 0;
  for (const b of bookings) {
    if (b.user_id === id && b.status === "confirmed") {
      b.status = "cancelled";
      const event = events.find((e) => e.id === b.event_id);
      if (event) event.available_seats += b.seats;
      cancelled++;
    }
  }
  await writeData("events", events);
  await writeData("bookings", bookings);

  await writeData("users", users.filter((u) => u.id !== id));
  const codes = await readData("codes");
  await writeData("codes", codes.filter((c) => c.user_id !== id));

  success(res, 200, "Akkaunt o'chirildi", { cancelledBookings: cancelled });
});
