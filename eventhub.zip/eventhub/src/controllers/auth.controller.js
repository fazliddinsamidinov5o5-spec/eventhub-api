// src/controllers/auth.controller.js
const bcrypt = require("bcrypt");
const { readData, writeData } = require("../utils/fileDb");
const { generateOtp } = require("../utils/generateCode");
const { safeSendMail } = require("../utils/mailer");
const T = require("../utils/emailTemplates");
const { ApiError, wrap, nextId, publicUser, success } = require("../utils/helpers");
const { validate } = require("../utils/validate");
const V = require("../validations/auth.validation");

const CODE_TTL_MS = 10 * 60 * 1000; // 10 daqiqa
const RESEND_COOLDOWN_MS = 60 * 1000; // 60 soniya
const MAX_ATTEMPTS = 5;

// Postman'da code raqam sifatida yuborilsa ham ishlashi uchun
const normalizeCode = (body) =>
  body && typeof body.code === "number" ? { ...body, code: String(body.code) } : body;

// Eski ishlatilmagan kodlarni used=true qiladi, yangisini yaratadi, oddiy (hashlanmagan) kodni qaytaradi
async function issueCode(userId, purpose) {
  const codes = await readData("codes");
  codes.forEach((c) => {
    if (c.user_id === userId && c.purpose === purpose && !c.used) c.used = true;
  });

  const otp = generateOtp();
  const now = Date.now();
  codes.push({
    id: nextId(codes),
    user_id: userId,
    code: await bcrypt.hash(otp, 10),
    purpose,
    attempts: 0,
    expires_at: new Date(now + CODE_TTL_MS).toISOString(),
    used: false,
    created_at: new Date(now).toISOString(),
  });
  await writeData("codes", codes);
  return otp;
}

// Oxirgi kod yaratilganiga 60 soniya o'tmaganmi?
async function isTooSoon(userId, purpose) {
  const codes = await readData("codes");
  const mine = codes.filter((c) => c.user_id === userId && c.purpose === purpose);
  if (!mine.length) return false;
  const last = mine.reduce((a, b) => (a.id > b.id ? a : b));
  return Date.now() - new Date(last.created_at).getTime() < RESEND_COOLDOWN_MS;
}

// Kodni tekshiradi (muddat, urinishlar, solishtirish). Muvaffaqiyatli bo'lsa { codes, record } qaytaradi
async function checkCode(userId, purpose, plainCode) {
  const codes = await readData("codes");
  const active = codes.filter((c) => c.user_id === userId && c.purpose === purpose && !c.used);
  if (!active.length) throw new ApiError(400, "Faol kod topilmadi. Yangi kod so'rang");
  const record = active.reduce((a, b) => (a.id > b.id ? a : b));

  if (record.attempts >= MAX_ATTEMPTS) {
    throw new ApiError(400, "Urinishlar soni tugadi. Yangi kod so'rang");
  }
  if (new Date(record.expires_at).getTime() < Date.now()) {
    throw new ApiError(400, "Kod muddati tugagan");
  }

  const match = await bcrypt.compare(plainCode, record.code);
  if (!match) {
    record.attempts += 1;
    await writeData("codes", codes);
    const left = MAX_ATTEMPTS - record.attempts;
    throw new ApiError(
      400,
      left > 0 ? `Kod noto'g'ri. Qolgan urinishlar: ${left}` : "Kod noto'g'ri. Urinishlar tugadi, yangi kod so'rang"
    );
  }
  return { codes, record };
}

// POST /api/auth/register
exports.register = wrap(async (req, res) => {
  const { full_name, email, password } = validate(V.registerSchema, req.body);

  const users = await readData("users");
  if (users.some((u) => u.email === email)) {
    throw new ApiError(409, "Bu email allaqachon ro'yxatdan o'tgan");
  }

  const user = {
    id: nextId(users),
    full_name,
    email,
    password: await bcrypt.hash(password, 10),
    is_verified: false,
    created_at: new Date().toISOString(),
  };
  users.push(user);
  await writeData("users", users);

  const otp = await issueCode(user.id, "verify_email");
  await safeSendMail(user.email, T.verificationEmail(user.full_name, otp));

  success(res, 201, "Ro'yxatdan o'tdingiz. Emailingizga tasdiqlash kodi yuborildi", publicUser(user));
});

// POST /api/auth/verify-email
exports.verifyEmail = wrap(async (req, res) => {
  const { email, code } = validate(V.verifyEmailSchema, normalizeCode(req.body));

  const users = await readData("users");
  const user = users.find((u) => u.email === email);
  if (!user) throw new ApiError(404, "Foydalanuvchi topilmadi");
  if (user.is_verified) throw new ApiError(400, "Email allaqachon tasdiqlangan");

  const { codes, record } = await checkCode(user.id, "verify_email", code);

  record.used = true;
  user.is_verified = true;
  await writeData("codes", codes);
  await writeData("users", users);

  await safeSendMail(user.email, T.welcomeEmail(user.full_name));
  success(res, 200, "Email muvaffaqiyatli tasdiqlandi", publicUser(user));
});

// POST /api/auth/resend-code
exports.resendCode = wrap(async (req, res) => {
  const { email } = validate(V.resendCodeSchema, req.body);

  const users = await readData("users");
  const user = users.find((u) => u.email === email);
  if (!user) throw new ApiError(404, "Foydalanuvchi topilmadi");
  if (user.is_verified) throw new ApiError(400, "Email allaqachon tasdiqlangan");

  if (await isTooSoon(user.id, "verify_email")) {
    throw new ApiError(429, "Iltimos, 60 soniyadan keyin urinib ko'ring");
  }

  const otp = await issueCode(user.id, "verify_email");
  await safeSendMail(user.email, T.verificationEmail(user.full_name, otp));
  success(res, 200, "Yangi tasdiqlash kodi yuborildi", null);
});

// POST /api/auth/login
exports.login = wrap(async (req, res) => {
  const { email, password } = validate(V.loginSchema, req.body);

  const users = await readData("users");
  const user = users.find((u) => u.email === email);
  const ok = user ? await bcrypt.compare(password, user.password) : false;
  if (!ok) throw new ApiError(401, "Email yoki parol noto'g'ri");
  if (!user.is_verified) throw new ApiError(403, "Avval emailingizni tasdiqlang");

  success(res, 200, "Muvaffaqiyatli kirdingiz", publicUser(user));
});

// POST /api/auth/forgot-password
exports.forgotPassword = wrap(async (req, res) => {
  const { email } = validate(V.forgotPasswordSchema, req.body);
  const message = "Agar bu email ro'yxatdan o'tgan bo'lsa, unga kod yuborildi";

  const users = await readData("users");
  const user = users.find((u) => u.email === email);

  // Email bor-yo'qligidan qat'i nazar javob bir xil
  if (user && !(await isTooSoon(user.id, "reset_password"))) {
    const otp = await issueCode(user.id, "reset_password");
    await safeSendMail(user.email, T.resetPasswordEmail(user.full_name, otp));
  }
  success(res, 200, message, null);
});

// POST /api/auth/reset-password
exports.resetPassword = wrap(async (req, res) => {
  const { email, code, new_password } = validate(V.resetPasswordSchema, normalizeCode(req.body));

  const users = await readData("users");
  const user = users.find((u) => u.email === email);
  if (!user) throw new ApiError(400, "Kod noto'g'ri yoki muddati tugagan");

  const { codes, record } = await checkCode(user.id, "reset_password", code);

  record.used = true;
  user.password = await bcrypt.hash(new_password, 10);
  await writeData("codes", codes);
  await writeData("users", users);

  await safeSendMail(user.email, T.passwordChangedEmail(user.full_name));
  success(res, 200, "Parol muvaffaqiyatli tiklandi", null);
});
